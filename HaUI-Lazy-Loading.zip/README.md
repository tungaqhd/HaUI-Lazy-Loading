# HaUI Lazy Loading

Addon tự động tải lại trang đăng ký học phần khi xảy ra lỗi, nếu thành công sẽ kêu ting ting :D

## Installation

Tải file cài đặt .zip về bằng cách ấn vào chữ Code trên kia kìa, xong ấn Download

Vào [chrome://extensions/](chrome://extensions/) tick vào Developer Mode

Ấn vào Load unpacked và chọn file zip vừa tải

## License
[GPL 3.0](https://choosealicense.com/licenses/gpl-3.0/)